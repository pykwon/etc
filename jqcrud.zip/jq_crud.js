$(document).ready(function(){
	$("#addForm").hide();
	$("#delForm").hide();
	$("#code_err1").hide();
	$("#code_err2").hide();
	$("#sang_err").hide();
	$("#su_err").hide();
	$("#dan_err").hide();
	$("#dcode_err").hide();
	
	$("#btn_addSangpum").click(function(){
		$("#addForm").slideToggle("fast");
		$("#txtCode").focus();
	});
	
	$("#btn_delSangpum").click(function(){
		$("#delForm").slideToggle("fast");
		$("delCode").focus();
	});
	
	
	$("#btn_insertCancel").click(function(){  //추가 취소
		$("#txtCode").val("");
		$("#txtSang").val("");
		$("#txtSu").val("");
		$("#txtDan").val("");
		$("#addForm").slideToggle("fast");
	});
	
	$("#btn_deleteCancel").click(function(){  //삭제 취소
		$("#delCode").val("");
		$("#delForm").slideToggle("fast");
	});
});